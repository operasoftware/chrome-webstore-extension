# chrome-webstore-extension

Contains the code of [Install Chrome Extensions](https://addons.opera.com/en-gb/extensions/details/download-chrome-extension-9/) hosted at https://addons.opera.com which allows users to install extensions from Google Chrome Web Store directly in Opera browser.
